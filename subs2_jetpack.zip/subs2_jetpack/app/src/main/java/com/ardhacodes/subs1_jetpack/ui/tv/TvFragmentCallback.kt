package com.ardhacodes.subs1_jetpack.ui.tv

import com.ardhacodes.subs1_jetpack.data.MovieTvEntity

interface TvFragmentCallback {
    fun onShareClick(mov: MovieTvEntity)
}
